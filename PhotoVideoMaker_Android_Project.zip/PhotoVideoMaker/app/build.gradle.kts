plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.example.photovideomaker"; compileSdk = 35
    defaultConfig { applicationId = "com.example.photovideomaker"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-transformer:1.10.1")
}
