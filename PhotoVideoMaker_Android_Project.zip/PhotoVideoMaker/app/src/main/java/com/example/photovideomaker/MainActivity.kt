package com.example.photovideomaker

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.*

@UnstableApi
class MainActivity : AppCompatActivity() {
    private val photos = mutableListOf<Uri>()
    private lateinit var status: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        photos.clear(); photos.addAll(uris)
        status.text = if (photos.isEmpty()) "কোনো ছবি নির্বাচন করা হয়নি" else "${photos.size}টি ছবি নির্বাচন করা হয়েছে"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32) }
        val title = TextView(this).apply { text="Photo Video Maker"; textSize=28f }
        status = TextView(this).apply { text="ছবি নির্বাচন করুন"; textSize=18f; setPadding(0,32,0,24) }
        val seconds = EditText(this).apply { hint="প্রতি ছবির সময় (সেকেন্ড)"; inputType=2; setText("3") }
        val pick = Button(this).apply { text="📷 ছবি নির্বাচন করুন" }
        val make = Button(this).apply { text="🎬 ভিডিও বানান" }
        box.addView(title); box.addView(status); box.addView(seconds); box.addView(pick); box.addView(make); setContentView(box)
        pick.setOnClickListener { picker.launch("image/*") }
        make.setOnClickListener {
            if (photos.isEmpty()) { Toast.makeText(this,"আগে ছবি নির্বাচন করুন",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val out = "${externalCacheDir}/photo_video_${System.currentTimeMillis()}.mp4"
            val duration = (seconds.text.toString().toLongOrNull() ?: 3L) * 1000
            val items = photos.map { uri -> EditedMediaItem.Builder(MediaItem.Builder().setUri(uri).setImageDurationMs(duration).build()).build() }
            val seq = EditedMediaItemSequence.withVideoFrom(items)
            val composition = Composition.Builder(seq).build()
            val transformer = Transformer.Builder(this).addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) { runOnUiThread { status.text="ভিডিও তৈরি হয়েছে:\n$out"; Toast.makeText(this@MainActivity,"ভিডিও তৈরি হয়েছে",Toast.LENGTH_LONG).show() } }
                override fun onError(composition: Composition, result: ExportResult, exception: ExportException) { runOnUiThread { status.text="ভিডিও তৈরি করতে সমস্যা: ${exception.message}" } }
            }).build()
            status.text="ভিডিও তৈরি হচ্ছে..."
            transformer.start(composition, out)
        }
    }
}
